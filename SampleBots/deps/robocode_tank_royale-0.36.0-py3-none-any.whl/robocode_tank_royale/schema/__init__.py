"""
Auto-generated __init__.py for schema types.
"""

from typing import Any, Type

from .game_started_event_for_observer import GameStartedEventForObserver
from .bot_ready import BotReady
from .won_round_event import WonRoundEvent
from .game_aborted_event import GameAbortedEvent
from .color import Color
from .bot_hit_wall_event import BotHitWallEvent
from .next_turn import NextTurn
from .bot_address import BotAddress
from .tick_event_for_observer import TickEventForObserver
from .game_ended_event_for_bot import GameEndedEventForBot
from .bullet_hit_bot_event import BulletHitBotEvent
from .round_ended_event_for_bot import RoundEndedEventForBot
from .server_handshake import ServerHandshake
from .participant import Participant
from .controller_handshake import ControllerHandshake
from .bullet_hit_wall_event import BulletHitWallEvent
from .game_started_event_for_bot import GameStartedEventForBot
from .initial_position import InitialPosition
from .bot_info import BotInfo
from .resume_game import ResumeGame
from .round_ended_event_for_observer import RoundEndedEventForObserver
from .bullet_hit_bullet_event import BulletHitBulletEvent
from .observer_handshake import ObserverHandshake
from .team_message_event import TeamMessageEvent
from .bot_state import BotState
from .tps_changed_event import TpsChangedEvent
from .game_ended_event_for_observer import GameEndedEventForObserver
from .pause_game import PauseGame
from .bullet_state import BulletState
from .bot_hit_bot_event import BotHitBotEvent
from .hit_by_bullet_event import HitByBulletEvent
from .start_game import StartGame
from .bullet_fired_event import BulletFiredEvent
from .bot_policy_update import BotPolicyUpdate
from .team_message import TeamMessage
from .bot_death_event import BotDeathEvent
from .results_for_observer import ResultsForObserver
from .round_started_event import RoundStartedEvent
from .bot_handshake import BotHandshake
from .skipped_turn_event import SkippedTurnEvent
from .game_resumed_event_for_observer import GameResumedEventForObserver
from .message import Message
from .game_paused_event_for_observer import GamePausedEventForObserver
from .results_for_bot import ResultsForBot
from .event import Event
from .bot_intent import BotIntent
from .bot_state_with_id import BotStateWithId
from .change_tps import ChangeTps
from .stop_game import StopGame
from .scanned_bot_event import ScannedBotEvent
from .game_setup import GameSetup
from .bot_list_update import BotListUpdate
from .tick_event_for_bot import TickEventForBot

__all__ = [
    "GameStartedEventForObserver",
    "BotReady",
    "WonRoundEvent",
    "GameAbortedEvent",
    "Color",
    "BotHitWallEvent",
    "NextTurn",
    "BotAddress",
    "TickEventForObserver",
    "GameEndedEventForBot",
    "BulletHitBotEvent",
    "RoundEndedEventForBot",
    "ServerHandshake",
    "Participant",
    "ControllerHandshake",
    "BulletHitWallEvent",
    "GameStartedEventForBot",
    "InitialPosition",
    "BotInfo",
    "ResumeGame",
    "RoundEndedEventForObserver",
    "BulletHitBulletEvent",
    "ObserverHandshake",
    "TeamMessageEvent",
    "BotState",
    "TpsChangedEvent",
    "GameEndedEventForObserver",
    "PauseGame",
    "BulletState",
    "BotHitBotEvent",
    "HitByBulletEvent",
    "StartGame",
    "BulletFiredEvent",
    "BotPolicyUpdate",
    "TeamMessage",
    "BotDeathEvent",
    "ResultsForObserver",
    "RoundStartedEvent",
    "BotHandshake",
    "SkippedTurnEvent",
    "GameResumedEventForObserver",
    "Message",
    "GamePausedEventForObserver",
    "ResultsForBot",
    "Event",
    "BotIntent",
    "BotStateWithId",
    "ChangeTps",
    "StopGame",
    "ScannedBotEvent",
    "GameSetup",
    "BotListUpdate",
    "TickEventForBot"
]

CLASS_MAP: dict[str, Type[Any]] = {
    "GameStartedEventForObserver": GameStartedEventForObserver,
    "BotReady": BotReady,
    "WonRoundEvent": WonRoundEvent,
    "GameAbortedEvent": GameAbortedEvent,
    "Color": Color,
    "BotHitWallEvent": BotHitWallEvent,
    "NextTurn": NextTurn,
    "BotAddress": BotAddress,
    "TickEventForObserver": TickEventForObserver,
    "GameEndedEventForBot": GameEndedEventForBot,
    "BulletHitBotEvent": BulletHitBotEvent,
    "RoundEndedEventForBot": RoundEndedEventForBot,
    "ServerHandshake": ServerHandshake,
    "Participant": Participant,
    "ControllerHandshake": ControllerHandshake,
    "BulletHitWallEvent": BulletHitWallEvent,
    "GameStartedEventForBot": GameStartedEventForBot,
    "InitialPosition": InitialPosition,
    "BotInfo": BotInfo,
    "ResumeGame": ResumeGame,
    "RoundEndedEventForObserver": RoundEndedEventForObserver,
    "BulletHitBulletEvent": BulletHitBulletEvent,
    "ObserverHandshake": ObserverHandshake,
    "TeamMessageEvent": TeamMessageEvent,
    "BotState": BotState,
    "TpsChangedEvent": TpsChangedEvent,
    "GameEndedEventForObserver": GameEndedEventForObserver,
    "PauseGame": PauseGame,
    "BulletState": BulletState,
    "BotHitBotEvent": BotHitBotEvent,
    "HitByBulletEvent": HitByBulletEvent,
    "StartGame": StartGame,
    "BulletFiredEvent": BulletFiredEvent,
    "BotPolicyUpdate": BotPolicyUpdate,
    "TeamMessage": TeamMessage,
    "BotDeathEvent": BotDeathEvent,
    "ResultsForObserver": ResultsForObserver,
    "RoundStartedEvent": RoundStartedEvent,
    "BotHandshake": BotHandshake,
    "SkippedTurnEvent": SkippedTurnEvent,
    "GameResumedEventForObserver": GameResumedEventForObserver,
    "Message": Message,
    "GamePausedEventForObserver": GamePausedEventForObserver,
    "ResultsForBot": ResultsForBot,
    "Event": Event,
    "BotIntent": BotIntent,
    "BotStateWithId": BotStateWithId,
    "ChangeTps": ChangeTps,
    "StopGame": StopGame,
    "ScannedBotEvent": ScannedBotEvent,
    "GameSetup": GameSetup,
    "BotListUpdate": BotListUpdate,
    "TickEventForBot": TickEventForBot,
}
